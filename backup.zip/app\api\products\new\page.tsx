"use client"
import { useEffect, useState } from "react"
import { useRouter } from "next/navigation"

export default function NewProduct() {
  const [categories,setCategories] = useState([])
  const [form,setForm] = useState({
    name:"",
    price:"",
    stock:"",
    categoryId:""
  })
  const router = useRouter()

  useEffect(()=>{
    fetch("/api/categories")
      .then(r=>r.json())
      .then(setCategories)
  },[])

  async function handleSubmit(e:any){
    e.preventDefault()

    await fetch("/api/products",{
      method:"POST",
      body: JSON.stringify({
        ...form,
        price: Number(form.price),
        stock: Number(form.stock)
      })
    })

    router.push("/admin/products")
  }

  return (
    <div className="p-6 max-w-xl space-y-6">
      <h1 className="text-3xl font-bold">Add Product</h1>

      <form onSubmit={handleSubmit} className="space-y-4">

        <input placeholder="Product name"
          className="border p-2 w-full rounded"
          onChange={(e)=>setForm({...form,name:e.target.value})}
        />

        <input placeholder="Price"
          className="border p-2 w-full rounded"
          onChange={(e)=>setForm({...form,price:e.target.value})}
        />

        <input placeholder="Opening stock"
          className="border p-2 w-full rounded"
          onChange={(e)=>setForm({...form,stock:e.target.value})}
        />

        <select
          className="border p-2 w-full rounded"
          onChange={(e)=>setForm({...form,categoryId:e.target.value})}
        >
          <option>Select Category</option>
          {categories.map((c:any)=>(
            <option key={c.id} value={c.id}>{c.name}</option>
          ))}
        </select>

        <button className="bg-green-600 text-white px-4 py-2 rounded">
          Create Product
        </button>

      </form>
    </div>
  )
}
