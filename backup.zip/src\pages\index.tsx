export default function Home() {
  return (
    <div style={{ padding: 40 }}>
      <h1>Ice Spot POS</h1>
      <p>Next.js is working 🎉</p>
    </div>
  )
}
