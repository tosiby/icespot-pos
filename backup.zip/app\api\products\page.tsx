"use client"
import useSWR from "swr"
import Link from "next/link"

const fetcher = (url:string)=>fetch(url).then(r=>r.json())

export default function ProductsPage() {
  const { data } = useSWR("/api/products", fetcher)

  if (!data) return <p className="p-6">Loading products...</p>

  return (
    <div className="p-6 space-y-6">
      <div className="flex justify-between">
        <h1 className="text-3xl font-bold">Products</h1>
        <Link href="/admin/products/new" className="bg-blue-600 text-white px-4 py-2 rounded">
          + Add Product
        </Link>
      </div>

      <div className="bg-white shadow rounded-xl p-4">
        {data.map((p:any)=>(
          <div key={p.id} className="border-b py-2 flex justify-between">
            <div>
              <p className="font-semibold">{p.name}</p>
              <p className="text-sm text-gray-500">{p.category.name}</p>
            </div>
            <div>
              ₹{p.price} | Stock: {p.stock}
            </div>
          </div>
        ))}
      </div>
    </div>
  )
}
