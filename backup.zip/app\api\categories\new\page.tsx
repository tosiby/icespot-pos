"use client"
import { useState } from "react"
import { useRouter } from "next/navigation"

export default function NewCategory() {
  const [name,setName] = useState("")
  const router = useRouter()

  async function handleSubmit(e:any){
    e.preventDefault()

    await fetch("/api/categories",{
      method:"POST",
      body: JSON.stringify({ name })
    })

    router.push("/admin/categories")
  }

  return (
    <div className="p-6 max-w-xl">
      <h1 className="text-3xl font-bold mb-6">Add Category</h1>

      <form onSubmit={handleSubmit} className="space-y-4">
        <input
          placeholder="Category name"
          className="border p-2 w-full rounded"
          value={name}
          onChange={(e)=>setName(e.target.value)}
        />

        <button className="bg-green-600 text-white px-4 py-2 rounded">
          Create Category
        </button>
      </form>
    </div>
  )
}
