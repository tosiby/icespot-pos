"use client"
import useSWR from "swr"
import Link from "next/link"

const fetcher = (url:string)=>fetch(url).then(r=>r.json())

export default function CategoriesPage() {
  const { data, mutate } = useSWR("/api/categories", fetcher)

  if (!data) return <p className="p-6">Loading categories...</p>

  return (
    <div className="p-6 space-y-6">
      <div className="flex justify-between">
        <h1 className="text-3xl font-bold">Categories</h1>
        <Link href="/admin/categories/new" className="bg-blue-600 text-white px-4 py-2 rounded">
          + Add Category
        </Link>
      </div>

      <div className="bg-white shadow rounded-xl p-4">
        {data.length === 0 && <p>No categories yet</p>}
        {data.map((cat:any)=>(
          <div key={cat.id} className="border-b py-2">
            {cat.name}
          </div>
        ))}
      </div>
    </div>
  )
}
